// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Warm up cosine schedule\n", stdout);
  return lionss_run_workload("cosineWarmup");
}
