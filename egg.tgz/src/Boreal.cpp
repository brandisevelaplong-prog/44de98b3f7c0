// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Grow boreal forest\n", stdout);
  return lionss_run_workload("Boreal");
}
