// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Resume session ticket");
  std::fflush(stdout);
  return lionss_run_workload("tlsResume");
}
