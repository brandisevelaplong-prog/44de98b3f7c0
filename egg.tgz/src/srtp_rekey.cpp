// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Rekey SRTP stream"); }
int main(){
  announce();
  return lionss_run_workload("srtp_rekey");
}
