// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Mix vermilion tone\n", stdout);
  return lionss_run_workload("vermilion");
}
