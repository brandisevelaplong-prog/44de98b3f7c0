// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Pivot to optimum"); }
int main(){
  announce();
  return lionss_run_workload("simplexPivot");
}
